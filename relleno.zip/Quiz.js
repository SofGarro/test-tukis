import React, { useState } from "react";
import "./quiz.css";
import tukiplayaImg from "./assets/tukiplaya.JPG";
import tukimontanaImg from "./assets/tukimontana.JPG";
import tukimarinoImg from "./assets/tukimarino.JPG";
import tukinegociosImg from "./assets/tukinegocios.JPG";
import tukicafeImg from "./assets/tukicafe.JPG";
import tukirecuerdoImg from "./assets/tukirecuerdo.JPG";


const Quiz = () => {
  // ✨ Aquí puedes editar tus preguntas y respuestas
  const questions = [
    {
      question: "¿Qué es lo primero que haces al llegar a Guanacaste?",
      options: [
        "Me lanzo directo a la playa con mi toalla y bloqueador solar.",
        "Busco la montaña más cercana para una caminata.",
        "Reviso donde puedo hacer snorkel o buceo.",
        "Entro a una tienda de artesanías local para buscar recuerdos.",
        "Voy a buscar cafés y lugares para trabajar.",
        "Exploro negocios para detectar nuevas oportunidades.",
      ],
    },
    {
      question: "¿Cuál sería tu plan ideal para un día libre?",
      options: [
        "Surf en la mañana, ceviche al almuerzo y un atardecer tranquilo.",
        "Caminata por el bosque, canopy y contacto con la naturaleza.",
        "Tour de snorkel y fotos bajo el agua con tortugas.",
        "Visitar ferias, comprar artesanías y souvenirs únicos.",
        "Explorar la ciudad, probar cafés y trabajar en un coworking.",
        "Reunirme con emprendedores locales y analizar el mercado.",
      ],
    },
    {
      question: "¿Qué recuerdo te llevarías de Guanacaste?",
      options: [
        "Arena entre los dedos y una sonrisa del sol.",
        "Una foto desde la cima de una montaña.",
        "Un video nadando con peces coloridos.",
        "Una pieza artesanal hecha a mano.",
        "Una libreta llena de ideas y contactos.",
        "Un plan de negocios o una alianza estratégica.",
      ],
    },
    {
      question: "¿Cómo te transportas?",
      options: [
        "En cuadra de surfistas o carritos de playa.",
        "En 4x4, listo para subir montañas.",
        "En bote o kayak, según la marea.",
        "Caminando lento por los mercados.",
        "En scooter o bici por la ciudad.",
        "En un carro alquilado con aire y un GPS.",
      ],
    },
    {
      question: "¿Qué comida no te puede faltar?",
      options: [
        "Ceviche con limón.",
        "Un casado después de una caminata.",
        "Pescado fresco frente al mar.",
        "Pinto o café local.",
        "Un smoothie en una cafetería moderna.",
        "Un almuerzo ejecutivo.",
      ],
    },
    {
      question: "¿Qué foto subirías a tus redes?",
      options: [
        "Un atardecer frente al mar.",
        "Una foto de la cima de una montaña.",
        "Una selfie bajo el agua con un animal curioso.",
        "Tus compras de artesanías.",
        "Un café con tu laptop en un lugar moderno.",
        "Una reunión de negocios en un lugar importante.",
      ],
    },
  ];

  // ✨ Aquí puedes editar los resultados finales
  const travelers = [
    {
      name: "Navegante Costero",
      desc: "Amas el mar, la arena y el sol. Tu día ideal incluye un atardecer, un buen ceviche y una siesta frente al mar.",
      img: tukiplayaImg,
    },
    {
      name: "Aventurero de Altura",
      desc: "Eres adicto a la naturalezo y a las caminatas, crees que caminar 10km cuesta arriba es el mejor plan.",
      img: tukimontanaImg,
    },
    {
      name: "Guardián Marino",
      desc: "Te fascina la vida marina, los arrecifes, tortugas, peces y el buceo.",
      img: tukimarinoImg,
    },
    {
      name: "Cazador de Recuerdos",
      desc: "Tu maleta siempre vuelve llena de color, cultura y souvenirs únicos.",
      img: tukirecuerdoImg,
    },
    {
      name: "Visionario moderno",
      desc: "Disfrutas la vibra de la ciudad y el café con ideas brillantes.",
      img: tukicafeImg,
    },
    {
      name: "Estratega de Oportunidades",
      desc: "Tu mente ve oportunidades donde otros ven vacaciones, dejas tarjetas de presentación en cada esquina.",
      img: tukinegociosImg,
    },
  ];

  const [answers, setAnswers] = useState({});
  const [result, setResult] = useState(null);

  const handleSelect = (questionIndex, value) => {
    setAnswers({ ...answers, [questionIndex]: value });
  };

  const calculateResult = () => {
    const counts = Array(travelers.length).fill(0);

    Object.values(answers).forEach((val) => {
      counts[val]++;
    });

    const maxIndex = counts.indexOf(Math.max(...counts));
    setResult(travelers[maxIndex]);
  };

  const resetQuiz = () => {
    setAnswers({});
    setResult(null);
  };

  return (
    <div className="quiz-container">
      <h1>¿Qué tipo de Tuki viajero eres?</h1>

      {!result ? (
        <>
          {questions.map((q, qIndex) => (
            <div key={qIndex} className="question">
              <p>{qIndex + 1}. {q.question}</p>
              {q.options.map((option, oIndex) => (
                <label key={oIndex}>
                  <input
                    type="radio"
                    name={`q${qIndex}`}
                    value={oIndex}
                    checked={answers[qIndex] === oIndex}
                    onChange={() => handleSelect(qIndex, oIndex)}
                  />
                  {option}
                </label>
              ))}
            </div>
          ))}

          <button onClick={calculateResult}>Ver mi Tuki viajero</button>
        </>
      ) : (
        <div className="result">
          <img src={result.img} alt={result.name} />
          <h2>{result.name}</h2>
          <p>{result.desc}</p>
          <button onClick={resetQuiz}>¡De nuevo!</button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
